package com.miniproject.pickupalarm.Interfaces;

import org.json.JSONArray;

public interface LocationChanged {
    void newLocation(JSONArray location);
}
