package com.miniproject.pickupalarm.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.google.firebase.auth.FirebaseAuth;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.miniproject.pickupalarm.R;
import com.miniproject.pickupalarm.Singletones.Alert;

import java.util.List;

public class SplashActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private Alert alert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        mAuth = FirebaseAuth.getInstance();
        alert = Alert.getInstance().setActivity(SplashActivity.this);
        Dexter.withContext(this)
                .withPermissions(Manifest.permission.READ_CONTACTS,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (mAuth.getCurrentUser() != null)
                                    if (alert.getSelectedContact().size() == 0)
                                        startActivity(new Intent(SplashActivity.this, MainActivity.class));
                                    else
                                        startActivity(new Intent(SplashActivity.this, SelectedPhoneActivity.class));
                                else
                                    startActivity(new Intent(SplashActivity.this, AuthenticationActivity.class));
                                finish();
                            }
                        }, 3000);
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {

                    }
                }).check();
    }
}