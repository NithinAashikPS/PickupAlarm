package com.miniproject.pickupalarm.Interfaces;

public interface ContactSelect {
    void onSelect(int position, boolean selectionStatus);
}
